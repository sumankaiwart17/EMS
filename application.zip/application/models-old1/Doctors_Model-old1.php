<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Doctors_Model extends CI_Model
{
    public function docData($docId)
    {
        $search = array(
            'doc_id' => $docId,
        );
        $q = $this->db->where($search)
            ->get('doctor_registration');
        $q1 = $this->db->where($search)
            ->get('doctor_details');
        if ($q->num_rows() && $q1->num_rows()) {
            $data = array(
                'docReg' => $q->result_array(),
                'docDet' => $q1->result_array(),
            );
            return $data;
        } else {
            return false;
        }
    }

    public function doctorsConsult($consultId)
    {
        $search = array(
            'doctor_consults.id' => $consultId,
        );
        $q = $this->db->select('doctor_consults.*,doctor_details.doc_name,doctor_details.picture as doc_pic,user_details.name,user_details.picture')
        ->from('doctor_consults')
        ->join('doctor_details','doctor_details.doc_id = doctor_consults.doc_id')
        ->join('user_details','user_details.email_id = doctor_consults.email_id','left')
        ->where($search)
        ->get();

        $data = array(
            'consultData' => $q->result_array(),
        );

        return $data;
    }

    public function addConsultation($data)
	{
        $this->db->insert('doctor_consults',$data);
    }

    public function updDoc($data)
    {
        $search = array(
            'doc_id' => $data['doc_id'],
        );
        $docReg = array(
            'doc_name' => $data['doc_name'],
            'adhar' => $data['adhar'],
        );
        if (array_key_exists('picture', $data)) {
            $docDet = array(
                'doc_name' => $data['doc_name'],
                'email_id' => $data['email_id'],
                'city' => $data['city'],
                'country' => $data['country'],
                'state' => $data['state'],
                'zip' => $data['zip'],
                'phone' => $data['phone'],
                'specialization' => $data['specialization'],
                'picture' => $data['picture'],
            );
        } else {
            $docDet = array(
                'doc_name' => $data['doc_name'],
                'email_id' => $data['email_id'],
                'city' => $data['city'],
                'country' => $data['country'],
                'state' => $data['state'],
                'zip' => $data['zip'],
                'phone' => $data['phone'],
                'specialization' => $data['specialization'],
            );
        }
        $this->db->where($search)
            ->update('doctor_registration', $docReg);
        $this->db->where($search)
            ->update('doctor_details', $docDet);

        $q = $this->db->where($docReg)
            ->get('doctor_registration');
        $q1 = $this->db->where($docDet)
            ->get('doctor_details');
        if ($q->num_rows() && $q1->num_rows()) {
            return true;
        } else {
            return false;
        }
    }

    public function delDoc($doc_id)
    {
        $search = array(
            'doc_id' => $doc_id,
        );
        $data = array(
            'hos_id' => NULL,
        );
        $this->db->where($search)
            ->update('doctor_details', $data);
        $check = array(
            'doc_id' => $doc_id,
            'hos_id' => '',
        );
        $q = $this->db->where($check)
            ->get('doctor_details');
        if ($q->num_rows()) {
            return true;
        } else {
            return false;
        }
    }

    public function doctorsProfile($docId)
    {
        $search = array(
            'doc_id' => $docId,
        );
        $q = $this->db->where($search)
            ->get('doctor_details');
        $q2 = $this->db->select('*')
            ->from('doctor_review_user')
            ->where($search)
            ->join('user_details', 'user_details.email_id = doctor_review_user.email_id')
            ->get();
        $q1 = $this->db->where($search)
            ->get('doctors_experience');
        $q3 = $this->db->select('doctor_consults.*,user_details.picture,user_details.name')
            ->from('doctor_consults')
            ->join('user_details', 'user_details.email_id = doctor_consults.email_id','left')
            ->where('doctor_consults.doc_id',$docId)
            ->get();
        if ($q->num_rows() && $q2->num_rows() && $q1->num_rows() && $q3->num_rows()) {
            $data = array(
                'doctorData' => $q->result_array(),
                'reviewData' => $q2->result_array(),
                'expData' => $q1->result_array(),
                'consultData' => $q3->result_array(),
            );
            return $data;
        } else {
            return false;
        }
    }

    public function topDoc()
    {
        $q = $this->db->select('doctor_details.*, avg(doctor_review_user.star_rating) as star_rating, count(doctor_review_user.star_rating) as review_count')
            ->from('doctor_details')
            ->join('doctor_review_user', 'doctor_review_user.doc_id = doctor_details.doc_id')
            // ->where($search)
            ->group_by('doctor_review_user.doc_id')
            ->order_by('star_rating', 'desc')
            ->get();
        // echo '<pre>';
        // print_R($q->result_array());
        if ($q->num_rows()) {
            $data = array(
                'topDocs' => $q->result_array(),
            );
            return $data;
        } else {
            return false;
        }
    }
    public function getConsultData($doc_id)
    {
        $consult = $this->db->where('doc_id',$doc_id)
                        ->get('doctor_consults')
                        ->result_array();
        if($consult){
            $data = array(
                'consult'=> $consult
            );
            return $data;
        }else{
            return false;
        }
    }
    public function getConsultDatabyId($consult_id){
        $consultData = $this->db->where('id',$consult_id)
                        ->get('doctor_consults')
                        ->result_array();
        if($consultData){
            $data = array(
                'consultData'=> $consultData
            );
            return $data;
        }else{
            return false;
        }
    }
    public function insertConsultData($data)
    {
        $search = array(
            'id' => $data['consult_id'],
        );
        $consult = array(
            'consult_query' => $data['query'],
            'answer' => $data['answer'],
        );
        $q = $this->db->where($search)
        ->update('doctor_consults', $consult);

        if ($q) {
            return true;
        } else {
            return false;
        }
    }
    public function deleteConsultData($consult_id){
        $q=  $this -> db -> where('id', $consult_id)
                    -> delete('doctor_consults');

                    if ($q) {
                        return true;
                    } else {
                        return false;
                    }
    }

    public function addPatient($data){
        $this->db->insert('hospital_patients',$data);
        $q = $this->db->where($data)
                      ->get('hospital_patients');
        if($q->num_rows()){
            return true;
        }else{
            return false;
        }
    }
}
