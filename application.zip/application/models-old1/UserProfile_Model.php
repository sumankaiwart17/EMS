<?php

class UserProfile_Model extends CI_Model{

    public function getData($email){
        $search = array(
            'email_id' => $email,
        );
        $q = $this->db->where($search)
                      ->get('user_details');
        $q2 = $this->db->where($search)
                    ->get('user_registration');
        if($q->num_rows() && $q2->num_rows()){
            $data = array(
                'name' => $q->row('name'),
                'password' => $q2->row('password'),
                'picture' => $q->row('picture'),
                'email_id' => $q->row('email_id'),
                'country' => $q->row('country'),
                'state' => $q->row('state'),
                'city' => $q->row('city'),
            );
            return $data;
        }else{
           return false;
        }
    }

    public function updateData($newData){
        $search = array(
            'email_id' => $newData['email_id'],
        );
        $userReg = array(
            'password' => $newData['password'],
        );
        $userDet = array(
            'name' => $newData['name'],
            'picture' => $newData['picture'],
        );

        // updating the tables
        $this->db->where($search)
                    ->update('user_registration',$userReg);

        $this->db->where($search)
                ->update('user_details',$userDet);

        // checking
        $check1 = array(
            'email_id' => $newData['email_id'],
            'password' => $newData['password'],
        );
        $q = $this->db->where($check1)
                ->get('user_registration');
        $check2 = array(
            'email_id' => $newData['email_id'],
            'name' => $newData['name'],
            'picture' => $newData['picture'],
        );
        $q2 = $this->db->where($check2)
                ->get('user_details');

        if($q->num_rows() && $q2->num_rows()){
            $userdata = array(
                'name' => $q2->row('name'),
                'picture' => $q2->row('picture'),
                'email_id' => $q2->row('email_id'),
                'country' => $q2->row('country'),
                'state' => $q2->row('state'),
                'city' => $q2->row('city'),

            );
            return $userdata;
        }else{
            return false;
        } 
    }

    

}
?>