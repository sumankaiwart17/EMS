<?php //	include 'controller.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  	<!-- //Meta tag Keywords -->
	<!-- Extra css code writen in this file-->
<!-- 	<link rel="stylesheet" href="<?php echo base_url('css/indexExtra.css') ?>" type="text/css" media="all">
 -->	<!-- Custom-Files -->
	<!-- Bootstrap css -->
	<link href="<?php echo base_url('css/style.css') ?>" rel="stylesheet" type="text/css" media="all" />
	<!-- Main css -->
	<link rel="stylesheet" href="<?php echo base_url('css/fontawesome-all.css') ?>">
	<!-- Font-Awesome-Icons-CSS -->
	<link href="<?php echo base_url('css/popuo-box.css') ?>" rel="stylesheet" type="text/css" media="all" />
	<!-- pop-up-box -->
	<link href="<?php echo base_url('css/menu.css') ?>" rel="stylesheet" type="text/css" media="all" />
	<!-- menu style -->
	<!-- //Custom-Files -->
	<!-- web fonts -->
	<link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&amp;subset=latin-ext" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	    rel="stylesheet">
	<!-- //web fonts -->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/kenwheeler/slick@1.8.1/slick/slick-theme.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/bdd84c35b8.js" crossorigin="anonymous"></script> 

  <!--**********************************-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/zxcvbn/4.2.0/zxcvbn.js"></script>

<script src="https://www.solodev.com/assets/password/strength.js"></script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<link rel="stylesheet" href="https://rawgit.com/gionkunz/chartist-js/master/dist/chartist.min.css">
<script src="https://rawgit.com/gionkunz/chartist-js/master/dist/chartist.min.js"></script>

</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark navbar-fixed-top bg-primary">
	<a class="navbar-brand" href="<?php echo site_url('/') ?>" ><img src="<?php echo base_url('images/AAHRS_logo5.png') ?>" height="50px" ></a>

  	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
 	</button>

  	<div class="collapse navbar-collapse" id="navbarSupportedContent">
  		<ul class="navbar-nav navbar-left text-center mr-xl-5">
			<li class="nav-item active mr-lg-2 mb-lg-0 mb-2">
				<a class="nav-link text-white" href="<?php echo site_url() ?>" style="color:black">Home
					<span class="sr-only">(current)</span>
				</a>
			</li>
			<li class="nav-item dropdown mr-lg-2 mb-lg-0 mb-2">
				<a style="color:black" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Diseases
				</a>
				<div class="dropdown-menu">
					<div class="agile_inner_drop_nav_info p-4">
						<h5 class="mb-3">Common Diseases</h5>
						<div class="row">
							<div class="col-sm-6 multi-gd-img">
								<ul class="multi-column-dropdown">
									<li>
										<a href="product.html">Ischemic heart disease</a>
									</li>
									<li>
										<a href="product.html">Stroke</a>
									</li>
									<li>
										<a href="product.html">Lower respiratory infections</a>
									</li>
									<li>
										<a href="product.html">Chronic obstructive pulmonary disease</a>
									</li>
									<li>
										<a href="product.html">Trachea, bronchus, and lung cancers</a>
									</li>
									<li>
										<a href="product.html">Diabetes mellitus</a>
									</li>
									<li>
										<a href="product.html">Alzheimerâs disease and other dementias</a>
									</li>
									<li>
										<a href="product.html">Dehydration due to diarrheal diseases</a>
									</li>
									<li>
										<a href="product.html">Tuberculosis</a>
									</li>
									<li>
										<a href="product.html">Cirrhosis</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</li>
			<li class="nav-item dropdown mr-lg-2 mb-lg-0 mb-2">
				<a style="color:black" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Syntoms
				</a>
				<div class="dropdown-menu">
					<div class="agile_inner_drop_nav_info p-4">
						<h5 class="mb-3">Syntoms</h5>
						<div class="row">
							<div class="col-sm-6 multi-gd-img">
								<ul class="multi-column-dropdown">
									<li>
										<a href="product2.html">Persistant cough , Shortness of Breath</a>
									</li>
									<li>
										<a href="product2.html">a sore throat , exacerbated asthma</a>
									</li>
									<li>
										<a href="product2.html">Increased feelings of anxiety, sadness</a>
									</li>
									<li>
										<a href="product2.html">Blood in the urine</a>
									</li>
									<li>
										<a href="product2.html">Sudden high fever. Pain behind the eyes.</a>
									</li>
									<li>
										<a href="product2.html">Dark-colored urine,itching of the skin.</a>
									</li>
									<li>
										<a href="product2.html">Rapid weight loss , unexplained tiredness.</a>
									</li>
									<li>
										<a href="product2.html">Increased thirst , Blurred vision.</a>
									</li>
									<li>
										<a href="product2.html">Intolerance to cold , Constipation.</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</li>
			<li class="nav-item dropdown mr-lg-2 mb-lg-0 mb-2">
				<a style="color:black" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Top Doctors
				</a>
				<div class="dropdown-menu">
					<a class="dropdown-item" href="product.html">Dr.Amitava Saha  (cancer specialist) <i class="fas fa-star ml-2"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star-half"></i></a>
					<a class="dropdown-item" href="product2.html">Dr.Swagata Choudhury  (neuro surgen) <i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i></a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="single.html">Dr.T Banerjee  (heart surgen)  <i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i></a>
					<a class="dropdown-item" href="single2.html">Dr.Rajarshi Dutta  (Endocrinologists)  <i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star-half"></i></a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="checkout.html">Dr.Sudip Sengupta  (Hematologists)  <i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i></a>
					<a class="dropdown-item" href="payment.html">Dr.S A Mallick (Pediatricians)  <i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star ml-1"></i><i class="fas fa-star-half"></i></a>
				</div>		
			</li>
		</ul>	
  
		<?php if(empty($_SESSION['email_id'])) { ?>
            <ul class="navbar-nav text-center navbar-right">
			  <!-- <li class="nav-item ">
                <a class="nav-link play-icon popup-with-zoom-anim text-white" href="#small-dialog1">
                  <i class="fas fa-map-marker"></i> Select Location&nbsp;&nbsp;</a>
              </li> -->
              <li class="nav-item ">
			  	<a class="nav-link text-white" href="#" data-toggle="modal" data-target="#" class="text-white">
                	<i class="fas fa-info"></i>&nbsp; About Us&nbsp;&nbsp;</a>
              </li>
			  <li class="nav-item ">
			  	<a class="nav-link text-white" href="#" data-toggle="modal" data-target="#" class="text-white">
                	<i class="fas fa-id-card"></i>&nbsp; Contact Us&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item" >
			  	<a class="nav-link text-white" styles="border: 1px ridge;" href="#" data-toggle="modal" data-target="#exampleModal" class="text-white">
                	<i class="fas fa-sign-in-alt"></i>&nbsp; Log In&nbsp;&nbsp;</a>
              </li>
              
            </ul>
        <?php } else { ?>
            <ul class="navbar-nav text-center navbar-right">
              <!-- <li class="nav-item ">
                <a class="nav-link play-icon popup-with-zoom-anim text-white" href="#small-dialog1">
                  <i class="fas fa-map-marker "></i> Select Location&nbsp;&nbsp;</a>
              </li> -->
            
              <li class="nav-item">
                <a class="nav-link text-white" href="<?php echo site_url('userProfile_Controller/viewProfile') ?>"  class="text-white">
                  <i class="fas fa-user-circle "></i> My Profile&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-white" href="Feedback2.php" class="text-white">
                  <i class="fas fa-comment"></i> Feedback&nbsp;&nbsp;</a>
              </li>
              
              <li class="nav-item text-white">
                <a class="nav-link text-white" href="<?php echo site_url('userProfile_Controller/logout') ?>" class="text-white">
                  <i class="fas fa-sign-out-alt"></i> Logout&nbsp;&nbsp;</a>
              </li>
            </ul>
        <?php } ?>
  	</div>
</nav>


  <!--**************************************************-->
  	<!-- Button trigger modal(select-location) -->
	<!-- <div id="small-dialog1" class="mfp-hide">
		<div class="select-city">
			<h3>
				<i class="fas fa-map-marker"></i> Select Your Location</h3>
			<select class="list_of_cities">
				<optgroup label="Popular Cities">
					<option selected style="display:none;color:#eee;">Select City</option>
					<option>Birmingham</option>
					<option>Anchorage</option>
					<option>Phoenix</option>
					<option>Little Rock</option>
					<option>Los Angeles</option>
					<option>Denver</option>
					<option>Bridgeport</option>
					<option>Wilmington</option>
					<option>Jacksonville</option>
					<option>Atlanta</option>
					<option>Honolulu</option>
					<option>Boise</option>
					<option>Chicago</option>
					<option>Indianapolis</option>
				</optgroup>
				<optgroup label="Alabama">
					<option>Birmingham</option>
					<option>Montgomery</option>
					<option>Mobile</option>
					<option>Huntsville</option>
					<option>Tuscaloosa</option>
				</optgroup>
				<optgroup label="Alaska">
					<option>Anchorage</option>
					<option>Fairbanks</option>
					<option>Juneau</option>
					<option>Sitka</option>
					<option>Ketchikan</option>
				</optgroup>
				<optgroup label="Arizona">
					<option>Phoenix</option>
					<option>Tucson</option>
					<option>Mesa</option>
					<option>Chandler</option>
					<option>Glendale</option>
				</optgroup>
				<optgroup label="Arkansas">
					<option>Little Rock</option>
					<option>Fort Smith</option>
					<option>Fayetteville</option>
					<option>Springdale</option>
					<option>Jonesboro</option>
				</optgroup>
				<optgroup label="California">
					<option>Los Angeles</option>
					<option>San Diego</option>
					<option>San Jose</option>
					<option>San Francisco</option>
					<option>Fresno</option>
				</optgroup>
				<optgroup label="Colorado">
					<option>Denver</option>
					<option>Colorado</option>
					<option>Aurora</option>
					<option>Fort Collins</option>
					<option>Lakewood</option>
				</optgroup>
				<optgroup label="Connecticut">
					<option>Bridgeport</option>
					<option>New Haven</option>
					<option>Hartford</option>
					<option>Stamford</option>
					<option>Waterbury</option>
				</optgroup>
				<optgroup label="Delaware">
					<option>Wilmington</option>
					<option>Dover</option>
					<option>Newark</option>
					<option>Bear</option>
					<option>Middletown</option>
				</optgroup>
				<optgroup label="Florida">
					<option>Jacksonville</option>
					<option>Miami</option>
					<option>Tampa</option>
					<option>St. Petersburg</option>
					<option>Orlando</option>
				</optgroup>
				<optgroup label="Georgia">
					<option>Atlanta</option>
					<option>Augusta</option>
					<option>Columbus</option>
					<option>Savannah</option>
					<option>Athens</option>
				</optgroup>
				<optgroup label="Hawaii">
					<option>Honolulu</option>
					<option>Pearl City</option>
					<option>Hilo</option>
					<option>Kailua</option>
					<option>Waipahu</option>
				</optgroup>
				<optgroup label="Idaho">
					<option>Boise</option>
					<option>Nampa</option>
					<option>Meridian</option>
					<option>Idaho Falls</option>
					<option>Pocatello</option>
				</optgroup>
				<optgroup label="Illinois">
					<option>Chicago</option>
					<option>Aurora</option>
					<option>Rockford</option>
					<option>Joliet</option>
					<option>Naperville</option>
				</optgroup>
				<optgroup label="Indiana">
					<option>Indianapolis</option>
					<option>Fort Wayne</option>
					<option>Evansville</option>
					<option>South Bend</option>
					<option>Hammond</option>
				</optgroup>
				<optgroup label="Iowa">
					<option>Des Moines</option>
					<option>Cedar Rapids</option>
					<option>Davenport</option>
					<option>Sioux City</option>
					<option>Waterloo</option>
				</optgroup>
				<optgroup label="Kansas">
					<option>Wichita</option>
					<option>Overland Park</option>
					<option>Kansas City</option>
					<option>Topeka</option>
					<option>Olathe </option>
				</optgroup>
				<optgroup label="Kentucky">
					<option>Louisville</option>
					<option>Lexington</option>
					<option>Bowling Green</option>
					<option>Owensboro</option>
					<option>Covington</option>
				</optgroup>
				<optgroup label="Louisiana">
					<option>New Orleans</option>
					<option>Baton Rouge</option>
					<option>Shreveport</option>
					<option>Metairie</option>
					<option>Lafayette</option>
				</optgroup>
				<optgroup label="Maine">
					<option>Portland</option>
					<option>Lewiston</option>
					<option>Bangor</option>
					<option>South Portland</option>
					<option>Auburn</option>
				</optgroup>
				<optgroup label="Maryland">
					<option>Baltimore</option>
					<option>Frederick</option>
					<option>Rockville</option>
					<option>Gaithersburg</option>
					<option>Bowie</option>
				</optgroup>
				<optgroup label="Massachusetts">
					<option>Boston</option>
					<option>Worcester</option>
					<option>Springfield</option>
					<option>Lowell</option>
					<option>Cambridge</option>
				</optgroup>
				<optgroup label="Michigan">
					<option>Detroit</option>
					<option>Grand Rapids</option>
					<option>Warren</option>
					<option>Sterling Heights</option>
					<option>Lansing</option>
				</optgroup>
				<optgroup label="Minnesota">
					<option>Minneapolis</option>
					<option>St. Paul</option>
					<option>Rochester</option>
					<option>Duluth</option>
					<option>Bloomington</option>
				</optgroup>
				<optgroup label="Mississippi">
					<option>Jackson</option>
					<option>Gulfport</option>
					<option>Southaven</option>
					<option>Hattiesburg</option>
					<option>Biloxi</option>
				</optgroup>
				<optgroup label="Missouri">
					<option>Kansas City</option>
					<option>St. Louis</option>
					<option>Springfield</option>
					<option>Independence</option>
					<option>Columbia</option>
				</optgroup>
				<optgroup label="Montana">
					<option>Billings</option>
					<option>Missoula</option>
					<option>Great Falls</option>
					<option>Bozeman</option>
					<option>Butte-Silver Bow</option>
				</optgroup>
				<optgroup label="Nebraska">
					<option>Omaha</option>
					<option>Lincoln</option>
					<option>Bellevue</option>
					<option>Grand Island</option>
					<option>Kearney</option>
				</optgroup>
				<optgroup label="Nevada">
					<option>Las Vegas</option>
					<option>Henderson</option>
					<option>North Las Vegas</option>
					<option>Reno</option>
					<option>Sunrise Manor</option>
				</optgroup>
				<optgroup label="New Hampshire">
					<option>Manchesters</option>
					<option>Nashua</option>
					<option>Concord</option>
					<option>Dover</option>
					<option>Rochester</option>
				</optgroup>
				<optgroup label="New Jersey">
					<option>Newark</option>
					<option>Jersey City</option>
					<option>Paterson</option>
					<option>Elizabeth</option>
					<option>Edison</option>
				</optgroup>
				<optgroup label="New Mexico">
					<option>Albuquerque</option>
					<option>Las Cruces</option>
					<option>Rio Rancho</option>
					<option>Santa Fe</option>
					<option>Roswell</option>
				</optgroup>
				<optgroup label="New York">
					<option>New York</option>
					<option>Buffalo</option>
					<option>Rochester</option>
					<option>Yonkers</option>
					<option>Syracuse</option>
				</optgroup>
				<optgroup label="North Carolina">
					<option>Charlotte</option>
					<option>Raleigh</option>
					<option>Greensboro</option>
					<option>Winston-Salem</option>
					<option>Durham</option>
				</optgroup>
				<optgroup label="North Dakota">
					<option>Fargo</option>
					<option>Bismarck</option>
					<option>Grand Forks</option>
					<option>Minot</option>
					<option>West Fargo</option>
				</optgroup>
				<optgroup label="Ohio">
					<option>Columbus</option>
					<option>Cleveland</option>
					<option>Cincinnati</option>
					<option>Toledo</option>
					<option>Akron</option>
				</optgroup>
				<optgroup label="Oklahoma">
					<option>Oklahoma City</option>
					<option>Tulsa</option>
					<option>Norman</option>
					<option>Broken Arrow</option>
					<option>Lawton</option>
				</optgroup>
				<optgroup label="Oregon">
					<option>Portland</option>
					<option>Eugene</option>
					<option>Salem</option>
					<option>Gresham</option>
					<option>Hillsboro</option>
				</optgroup>
				<optgroup label="Pennsylvania">
					<option>Philadelphia</option>
					<option>Pittsburgh</option>
					<option>Allentown</option>
					<option>Erie</option>
					<option>Reading</option>
				</optgroup>
				<optgroup label="Rhode Island">
					<option>Providence</option>
					<option>Warwick</option>
					<option>Cranston</option>
					<option>Pawtucket</option>
					<option>East Providence</option>
				</optgroup>
				<optgroup label="South Carolina">
					<option>Columbia</option>
					<option>Charleston</option>
					<option>North Charleston</option>
					<option>Mount Pleasant</option>
					<option>Rock Hill</option>
				</optgroup>
				<optgroup label="South Dakota">
					<option>Sioux Falls</option>
					<option>Rapid City</option>
					<option>Aberdeen</option>
					<option>Brookings</option>
					<option>Watertown</option>
				</optgroup>
				<optgroup label="Tennessee">
					<option>Memphis</option>
					<option>Nashville</option>
					<option>Knoxville</option>
					<option>Chattanooga</option>
					<option>Clarksville</option>
				</optgroup>
				<optgroup label="Texas">
					<option>Houston</option>
					<option>San Antonio</option>
					<option>Dallas</option>
					<option>Austin</option>
					<option>Fort Worth</option>
				</optgroup>
				<optgroup label="Utah">
					<option>Salt Lake City</option>
					<option>West Valley City</option>
					<option>Provo</option>
					<option>West Jordan</option>
					<option>Orem</option>
				</optgroup>
				<optgroup label="Vermont">
					<option>Burlington</option>
					<option>Essex</option>
					<option>South Burlington</option>
					<option>Colchester</option>
					<option>Rutland</option>
				</optgroup>
				<optgroup label="Virginia">
					<option>Virginia Beach</option>
					<option>Norfolk</option>
					<option>Chesapeake</option>
					<option>Arlington</option>
					<option>Richmond</option>
				</optgroup>
				<optgroup label="Washington">
					<option>Seattle</option>
					<option>Spokane</option>
					<option>Tacoma</option>
					<option>Vancouver</option>
					<option>Bellevue</option>
				</optgroup>
				<optgroup label="West Virginia">
					<option>Charleston</option>
					<option>Huntington</option>
					<option>Parkersburg</option>
					<option>Morgantown</option>
					<option>Wheeling</option>
				</optgroup>
				<optgroup label="Wisconsin">
					<option>Milwaukee</option>
					<option>Madison</option>
					<option>Green Bay</option>
					<option>Kenosha</option>
					<option>Racine</option>
				</optgroup>
				<optgroup label="Wyoming">
					<option>Cheyenne</option>
					<option>Casper</option>
					<option>Laramie</option>
					<option>Gillette</option>
					<option>Rock Springs</option>
				</optgroup>
			</select>
			<div class="clearfix"></div>
		</div>
	</div> -->
	<!-- //shop locator (popup) -->

	<!-- modals -->
	<!-- log in -->
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-center">Log In</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?php echo site_url('userProfile_Controller/login') ?>" method="post">
						<div class="form-group">
							<label class="col-form-label">Username</label>
							<input type="text" class="form-control" placeholder=" " name="email" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Password</label>
							<input type="password" class="form-control" placeholder=" " name="password" required="">
						</div>
						<div class="right-w3l">
							<input type="submit" class="form-control" value="Login" name="Login">
						</div>
            <center><h3><a href="#" data-toggle="modal" data-target="#exampleModal19">Forgot Password</a></h3></center>
						<div class="sub-w3l">
							<div class="custom-control custom-checkbox mr-sm-2">
                <input type="checkbox" class="custom-control-input" id="customControlAutosizing" >
								 <label class="custom-control-label" for="customControlAutosizing" >Remember me?</label>
							</div>
						</div>
						<p class="text-center dont-do mt-3">Don't have an account?
							<a href="<?php echo site_url('userProfile_Controller/regPage') ?>" >
								Register Now</a>
						</p>
						
					</form>
					
				</div>
				<!--
				<div class="modal-body">
					<form action="Login" method="post">
						<div class="form-group">
							<label class="col-form-label">Username</label>
							<input type="text" class="form-control" placeholder=" " name="Name" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Password</label>
							<input type="password" class="form-control" placeholder=" " name="Password" required="">
						</div>
						<div class="right-w3l">
							<input type="submit" class="form-control" value="Log in">
						</div>
						<div class="sub-w3l">
							<div class="custom-control custom-checkbox mr-sm-2">
								<input type="checkbox" class="custom-control-input" id="customControlAutosizing">
								<label class="custom-control-label" for="customControlAutosizing">Remember me?</label>
							</div>
						</div>
						<p class="text-center dont-do mt-3">Don't have an account?
							<a href="#" data-toggle="modal" data-target="#exampleModal2">
								Register Now</a>
						</p>
					</form>
				</div>-->
			</div>
		</div>
	</div>
	<!-- <div class="modal fade" id="hospital" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-center">Log In Hospital</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?php echo site_url('hospital_Controller/login') ?>" method="post">
						<div class="form-group">
							<label class="col-form-label">Hospital ID</label>
							<input type="text" class="form-control" placeholder=" " name="hos_id" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Password</label>
							<input type="password" class="form-control" placeholder=" " name="password" required="">
						</div>
						<div class="right-w3l">
							<input type="submit" class="form-control" value="Login" name="Login">
						</div>
						<div class="sub-w3l">
							<div class="custom-control custom-checkbox mr-sm-2">
								<input type="checkbox" class="custom-control-input" id="customControlAutosizing">
								<label class="custom-control-label" for="customControlAutosizing">Remember me?</label>
							</div>
						</div>
						<p class="text-center dont-do mt-3">Don't have an account?
							<a href="#" data-toggle="modal" data-target="#exampleModal4">
								Register Now</a>
						</p>
					</form>
				</div>
			</div>
		</div>
	</div> -->
	<!-- register -->
	<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Register</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="register.php" method="post">
						<div class="form-group">
							<label class="col-form-label">Your Name</label>
							<input type="text" class="form-control" placeholder=" " name="name" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Email</label>
							<input type="email" class="form-control" placeholder=" " name="email" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Phone Number</label>
							<input type="text" class="form-control" placeholder=" " name="phone" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Password</label>
							<input type="password" class="form-control" placeholder=" " name="Password" id="password" required="">
						</div>
						<!--
						<div class="form-group">
							<label class="col-form-label">Confirm Password</label>
							<input type="password" class="form-control" placeholder=" " name="Confirm Password" id="password2" required="">
						</div>-->
						<div class="right-w3l">
							<input type="submit" class="form-control" value="Register" name="submit">
						</div>
						<div class="sub-w3l">
							<div class="custom-control custom-checkbox mr-sm-2">
								<input type="checkbox" class="custom-control-input" id="customControlAutosizing2">
								<label class="custom-control-label" for="customControlAutosizing2">I Accept to the Terms & Conditions</label>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="exampleModal19" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Change Password</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="change" method="post">
					<center>
					<h2>
					<div class="form-group"><label class="col-form-label">Email</label><br>
					<input type="text" name="email"></div>
					<div class="form-group"><label class="col-form-label">New Password</label>
					<input type="password" class="form-control" placeholder=" " name="password1" required=""></div>
					<div class="form-group">
					<label class="col-form-label">Confirm Password</label>
					<input type="password" class="form-control" placeholder=" " name="password2" required=""></div>
					<br>
					<div class="right-w3l">
					<input type="submit" value="submit" name="submit" style="height:50px; width:250px"></div>
					</h2>
					</center>
					</form>
					</div></div></div></div>
		<div class="modal fade" id="exampleModal4" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Register Hospital</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?php echo site_url('hospital_Controller/register') ?>" method="post">
					<div class="form-group">
							<label class="col-form-label">Hospital Name</label>
							<input type="text" class="form-control" placeholder=" " name="hname" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">H_ID</label>
							<input type="text" class="form-control" placeholder=" " name="hid" required="">
						</div>
						
						<div class="form-group">
							<label class="col-form-label">Email</label>
							<input type="email" class="form-control" placeholder=" " name="email" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Password</label>
							<input type="password" class="form-control" placeholder=" " name="password" id="password1" required="">
						</div>
						<div class="form-group">
							<label class="col-form-label">Confirm Password</label>
							<input type="password" class="form-control" placeholder=" " id="cpassword" required="">
						</div>
						<div class="form-group row">
							<div class="col">
								<label for="country">Country</label>
								<input type="text" class="form-control" id="country" name="country" placeholder="Country" required="">
							</div>
							<div class="col">
								<label for="state">State</label>
								<input type="text" class="form-control" id="state" name="state" placeholder="State" required="">
							</div>
							<div class="col">
								<label for="city">City</label>
								<input type="text" class="form-control" id="city" name="city" placeholder="City" required="">
							</div>
						</div>
						<div class="form-group row">
							<div class="col">
								<label for="zip">Zip Code</label>
								<input type="text" class="form-control" id="zip" name="zip" placeholder="postal zip" required="">
							</div>
							<div class="col">
								<label for="phnnum">Phone Number</label>
								<input type="text" class="form-control" id="phnnum" name="phone" placeholder="Phone No." required="">
							</div>
						</div>
						<div class="form-group">
							<label for="logo">Select Logo</label>
							<input type="file" class="form-control-file" name="logo" id="logo">
						</div>
						<div class="right-w3l">
							<input type="submit" class="form-control" value="Register">
						</div>
						<div class="sub-w3l">
							<div class="custom-control custom-checkbox mr-sm-2">
								<input type="checkbox" class="custom-control-input" id="customControlAutosizing2">
								<label class="custom-control-label" for="customControlAutosizing2">I Accept to the Terms & Conditions</label>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<br>
	<!-- //modal -->
	<!-- //top-header -->

	<!-- header-bottom-->
	<!-- <div class="header-bot">
		<div class="container">
			<div class="row header-bot_inner_wthreeinfo_header_mid">
				
				 <div class="col-md-4 header mt-4 mb-md-0 mb-4">
					<div class="row">
						<div class="col-12 agileits_search">
							<form class="form-inline" action="#" method="post">
								<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" required>
								<button class="btn my-2 my-sm-0" type="submit">Search</button>
							</form>
						</div>
					</div>
				</div> -->
				
			<!-- </div>
			
		</div>
	</div> -->
	<!-- shop locator (popup) -->
  <!-- //header-bottom -->
  <!--*******************************************************************************-->
<!--
 <nav class="navbar navbar-expand-md navbar-dark">
  <a class="navbar-brand" style="font-size: 35px;" href="#">AAHRS</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar" style="margin-left: 200px;">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
    </ul>
    <ul class="nav navbar-nav navbar-right">
        <li class="nav-item active">
            <a class="nav-link" href="#"><i class="fas fa-hospital fa-fw mr-1 "></i>Welcome<span class="sr-only">(current)</span></a>
          </li>
        <li class="nav-item">
            <a class="nav-link" href="#"><i class="fa fa-map-marker fa-fw mr-1"></i>Select Location</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"><i class="fa fa-phone fa-fw fa-rotate-180 mr-1"></i> 001 234 5678</a>
          </li>
        <li class="nav-item">
            <a class="nav-link" href="#"><i class="fas fa-user fa-fw mr-1"></i>Profile</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"><i class="fa fa-info-circle fa-fw mr-1"></i>Feedback</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"><i class="fa fa-sign-out-alt fa-fw mr-1"></i>Logout</a>
          </li>
      </ul>
    
  </div>  
</nav> -->
<!--***************************************************************-->
<!-- jquery -->
	<!-- popup modal (for location)-->
	<!-- <script src="<?php echo base_url('js/jquery.magnific-popup.js') ?>"></script> -->
	<script>
		$(document).ready(function () {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});

		});
	</script>
	<!-- //popup modal (for location)-->

	
<!--***************************************************************-->
<br>
</body>
</html>


