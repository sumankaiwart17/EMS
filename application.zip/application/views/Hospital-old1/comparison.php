<?php if(!$_SESSION['email_id']){
    header ('location:'.site_url('mainController/temp'));
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Comparison</title>
</head>
<body>
    <!-- Navbar -->
<?php include ('navbar.php'); ?>
        <!-- Dashboard -->
        <div class="page-wrapper">
            <div class="content">
            <div class="row">
					<div class="col-12 col-md-6 col-lg-6 col-xl-6">
						<div class="card">
							<div class="card-body">
								<div class="chart-title">
									<h4>Reviews</h4>
									<span class="float-right"><i class="fa fa-caret-up" aria-hidden="true"></i> 15% Higher than Last Month</span>
                                    <select class="float-right mr-2" name="" id="comp">
                                        <option value="">Avg</option>
                                        <option value="">Hos A</option>
                                        <option value="">Hos B</option>
                                        <option value="">Hos C</option>
                                    </select>
                                    <label class="float-right mr-2" for="comp">Compare With</label>
								</div>	
								<canvas id="linegraph"></canvas>
							</div>
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 col-xl-6">
						<div class="card">
							<div class="card-body">
								<div class="chart-title">
									<h4>No. of Patients</h4>
									<!-- <div class="float-right">
										<ul class="chat-user-total">
											<li><i class="fa fa-circle current-users" aria-hidden="true"></i>ICU</li>
											<li><i class="fa fa-circle old-users" aria-hidden="true"></i> OPD</li>
										</ul>
									</div> -->
                                    <select class="float-right mr-2" name="" id="comp">
                                        <option value="">Avg</option>
                                        <option value="">Hos A</option>
                                        <option value="">Hos B</option>
                                        <option value="">Hos C</option>
                                    </select>
                                    <label class="float-right mr-2" for="comp">Compare With</label>
								</div>	
								<canvas id="bargraph"></canvas>
							</div>
						</div>
					</div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                    <div class="hospital-barchart">
                        <h4 class="card-title d-inline-block">Social Engagement</h4>
                    </div>
                    <div class="bar-chart">
                        <div class="legend">
                            <div class="item">
                                <h4>Level1</h4>
                            </div>
                            
                            <div class="item">
                                <h4>Level2</h4>
                            </div>
                            <div class="item text-right">
                                <h4>Level3</h4>
                            </div>
                            <div class="item text-right">
                                <h4>Level4</h4>
                            </div>
                        </div>
                        <div class="chart clearfix">
                            <div class="item">
                                <div class="bar">
                                    <span class="percent">30%</span>
                                    <div class="item-progress" data-percent="30">
                                        <span class="title">Likes</span>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="bar">
                                    <span class="percent">71%</span>
                                    <div class="item-progress" data-percent="71">
                                        <span class="title">Comments</span>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="bar">
                                    <span class="percent">82%</span>
                                    <div class="item-progress" data-percent="82">
                                        <span class="title">Shares</span>
                                    </div>
                                </div>
                            </div><!-- 
                            <div class="item">
                                <div class="bar">
                                    <span class="percent">67%</span>
                                    <div class="item-progress" data-percent="67">
                                        <span class="title">Treatment</span>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="bar">
                                    <span class="percent">30%</span>									
                                    <div class="item-progress" data-percent="30">
                                        <span class="title">Discharge</span>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                 </div>
				</div>
               
            </div>	
        </div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


    <script src="<?php echo base_url() ?>/js/jquery.slimscroll.js"></script>
    <script src="<?php echo base_url() ?>/js/Chart.bundle.js"></script>
    <script src="<?php echo base_url() ?>/js/chart.js"></script>
    <script src="<?php echo base_url() ?>/js/app.js"></script>
</body>
</html>