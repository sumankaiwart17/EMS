
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title></title>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-primary">
        <a class="navbar-brand ml-3" href="#"><img src="<?php echo base_url('images/AAHRS_logo5.png') ?>" class="" style="height: 30px;" alt="logo"></a>
      
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- <a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
            <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a> -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto mr-4">
                <li class="nav-item">
                    <a class="nav-link" href="#"><i class="fas fa-bell"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"><i class="fas fa-comment"></i></a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo $_SESSION['hos_name'] ?>
                    </a>
                    <div class="dropdown-menu mt-2" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo site_url('hospital_Controller/profile') ?>">View Profile</a>
                    <a class="dropdown-item" href="<?php echo site_url('hospital_Controller/editprofile') ?>">Edit Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo site_url('hospital_Controller/logout') ?>">Log Out</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
<!-- side nav -->
        <div class="sidebar mt-2 " id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li <?php if($this->uri->segment(2) == 'dashboard'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/dashboard') ?>"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'profile'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/profile') ?>"><i class="fas fa-user-circle"></i> <span>Profile</span></a>
                        </li>
						<li <?php if($this->uri->segment(2) == 'doctors'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/doctors') ?>"><i class="fa fa-user-md"></i> <span>Doctors</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'patients'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/patients') ?>"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'appointments'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/appointments') ?>"><i class="fa fa-calendar"></i> <span>Appointments</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'schedule'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/schedule') ?>"><i class="fas fa-calendar-check"></i> <span>Doctor Schedule</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'departments'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/departments') ?>"><i class="fas fa-hospital"></i> <span>Departments</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'treatments'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/treatments') ?>"><i class="fas fa-procedures"></i> <span>Treatments & Packages</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'cusQueries'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/cusQueries') ?>"><i class="fa fa-comments"></i> <span>Customers' Query</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'hosOffers'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/hosOffers') ?>"><i class="fas fa-ticket-alt"></i> <span>Offers</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'hosAdvertise'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/hosAdvertise') ?>"><i class="fas fa-ad"></i> <span>Advertisement</span></a>
                        </li>
                        <li <?php if($this->uri->segment(2) == 'comparison'): ?> class="active" <?php endif; ?> >
                            <a href="<?php echo site_url('hospital_Controller/comparison') ?>"><i class="fas fa-chart-bar"></i> <span>Comparison</span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>


        <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
 --><script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <!-- <script src="<?php echo base_url() ?>css/assets/js/jquery-3.2.1.min.js"></script>
	<script src="<?php echo base_url() ?>css/assets/js/popper.min.js"></script>
    <script src="<?php echo base_url() ?>css/assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>css/assets/js/jquery.slimscroll.js"></script>
    <script src="<?php echo base_url() ?>css/assets/js/select2.min.js"></script>
	<script src="<?php echo base_url() ?>css/assets/js/moment.min.js"></script>
	<script src="<?php echo base_url() ?>css/assets/js/bootstrap-datetimepicker.min.js"></script>
    <script src="<?php echo base_url() ?>css/assets/js/app.js"></script> -->
</body>
</html>