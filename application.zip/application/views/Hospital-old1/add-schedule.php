
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/bootstrap-datetimepicker.min.css') ?>">
    <link rel="stylesheet" href="https://res.cloudinary.com/dxfq3iotg/raw/upload/v1569006288/BBBootstrap/choices.min.css?version=7.0.0">
<script src="https://res.cloudinary.com/dxfq3iotg/raw/upload/v1569006273/BBBootstrap/choices.min.js?version=7.0.0"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Dashboard</title>
    <style>
        .time-icon:after {
	background: transparent url("<?php echo base_url('images/') ?>clock.png") no-repeat scroll 0 0;
	bottom: 0;
	content: "";
	display: block;
	height: 19px;
	margin: auto;
	position: absolute;
	right: 15px;
	top: 0;
	width: 19px;
}
.time-icon {
	position: relative;
	width: 100%;
}
    </style>
</head>
<body>
    <!-- Navbar -->
<?php include ('navbar.php'); ?>
        <!-- Add Doctor -->
        
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Add Schedule</h4>
                    </div>
                </div>
                <?php if(isset($doctors)): ?>
                <div class="row p-3">
                    <div class="col-lg-8 offset-lg-2">
                        <form action="<?php echo site_url('hospital_Controller/addSchedule') ?>" method="post">
                            <div class="row pt-3 pb-3">
                                <div class="col-md-6">
                                    <div class="form-group">
										<label>Doctor Name</label>
										<select name="doc_id" class="form-control">
											<option>Select a Doctor</option>
                                            <?php foreach($doctors as $x): ?>
                                                <option value="<?php echo $x['doc_id'] ?>"><?php echo $x['doc_name'] ?></option>
                                            <?php endforeach; ?>
										</select>
									</div>
                                </div>
                                <div class="col-md-6">
									<div class="form-group">
										<label>Available Days</label>
										<select name="weekdays[]" size="6" id="choices-multiple-remove-button" placeholder="Select Days" multiple>
											<option value="Sun">Sunday</option>
											<option value="Mon">Monday</option>
											<option value="Tue">Tuesday</option>
											<option value="Wed">Wednesday</option>
											<option value="Thur">Thursday</option>
											<option value="Fri">Friday</option>
											<option value="Sat">Saturday</option>
										</select>
									</div>
                                </div>
                            </div>
                            <div class="row pt-3 pb-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Start Time</label>
                                        <div class="time-icon">
                                            <input name="strt_time" type="text" class="form-control" id="datetimepicker3">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>End Time</label>
                                        <div class="time-icon">
                                            <input name="end_time" type="text" class="form-control" id="datetimepicker4">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row pt-3 pb-3">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Break Time</label>
                                        <div class="time-icon">
                                            <input name="brk_time" type="text" class="form-control" id="datetimepicker5">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Break Duration <small><strong>(in hrs)</strong></small></label>
                                        <div class="">
                                            <input name="brk_dur" type="number" class="form-control" id="brk_dur">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Appointment Duration <small><strong>(in mins)</strong></small></label>
                                        <div class="">
                                            <input name="appt_dur" type="number" class="form-control" id="brk_dur">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group pt-3 pb-3">
                                <label class="display-block">Schedule Status</label>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_active" value="1" checked>
									<label class="form-check-label" for="product_active">
									Active
									</label>
								</div>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_inactive" value="0">
									<label class="form-check-label" for="product_inactive">
									Inactive
									</label>
								</div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button type="submit" class="btn btn-primary submit-btn">Create Schedule</button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php else: ?>
                <?php endif; ?>
            </div>
			
        </div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="<?php echo base_url('js/moment.min.js') ?>"></script>
<script src="<?php echo base_url('js/select2.min.js') ?>"></script>
<script src="<?php echo base_url('js/bootstrap-datetimepicker.min.js') ?>"></script>
<script src="<?php echo base_url('js/app.js') ?>"></script>

<script>
    $(document).ready(function($) {
        $(function () {
                $('#datetimepicker3').datetimepicker({
                    format: 'LT'
                });
				$('#datetimepicker4').datetimepicker({
                    format: 'LT'
                });
                $('#datetimepicker5').datetimepicker({
                    format: 'LT'
                });
            });
    });
    $(document).ready(function(){

    var multipleCancelButton = new Choices('#choices-multiple-remove-button', {
        removeItemButton: true,
        maxItemCount:6,
        searchResultLimit:7,
        renderChoiceLimit:7
        });


    });
</script>
</body>
</html>