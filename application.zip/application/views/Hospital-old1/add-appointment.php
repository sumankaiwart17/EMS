<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/bootstrap-datetimepicker.min.css') ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('css/cssUser/') ?>dist/css/pignose.calendar.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Appointments</title>
    <style>
        .cal-icon:after {
	background: transparent url("<?php echo base_url('images/') ?>calander.png") no-repeat scroll 0 0;
	bottom: 0;
	content: "";
	display: block;
	height: 19px;
	margin: auto;
	position: absolute;
	right: 15px;
	top: 0;
	width: 17px;
}
.cal-icon {
	position: relative;
	width: 100%;
}
.time-icon:after {
	background: transparent url("<?php echo base_url('images/') ?>clock.png") no-repeat scroll 0 0;
	bottom: 0;
	content: "";
	display: block;
	height: 19px;
	margin: auto;
	position: absolute;
	right: 15px;
	top: 0;
	width: 19px;
}
.time-icon {
	position: relative;
	width: 100%;
}
    </style>
</head>
<body>
    <!-- Navbar -->
    <?php include ('navbar.php'); ?>
        <!-- Appointments -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                        <div class="col-sm-4 col-3">
                            <h4 class="page-title">Add Appointments</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php //print_r($departments); ?>
                    <div class="col-lg-8 offset-lg-2">
                        <form method="POST" action="<?php echo site_url('hospital_Controller/save_appointment_data'); ?>">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
										<label>Appointment ID</label>
										<input class="form-control" type="text" name="appt_id" value="<?php echo uniqid('APPT'); ?>" readonly>
									</div>
                                </div>
                                <div class="col-md-6">
									<div class="form-group">
                                        <label>Patient Name</label>
										<input class="form-control" type="text" name="pt_name">
									</div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Department</label>
                                        <select class="form-control" id="dept_id" name="dept_id">
                                            <option value="">Select a Department</option>
                                            <?php foreach($departments as $x){ ?>
                                            <option value="<?php echo $x['dept_id'] ?>"><?php echo $x['dept_name'] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Doctor</label>
                                        <select class="form-control" id="doc_id" name="doc_id">
                                       
                                            <option value="">Select a Department</option>
                                         
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Date</label>
                                        <div class="cal-icon">
                                            <input type="text" class="form-control input-calendar" name="date">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Time</label>
                                        <div class="time-icon">
                                            <input type="text" class="form-control" id="datetimepicker3" name="time">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Patient Email</label>
                                        <input class="form-control" type="email" name="email">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Patient Phone Number</label>
                                        <input class="form-control" type="text" name="phone">
                                    </div>
                                </div>
                            </div>
                         
                            <div class="form-group">
                                <label class="display-block">Appointment Status</label>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_active" value="1" checked>
									<label class="form-check-label" for="product_active">
									Active
									</label>
								</div>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_inactive" value="0">
									<label class="form-check-label" for="product_inactive">
									Inactive
									</label>
								</div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn" type="submit">Create Appointment</button>
                            </div>
                        </form>
                    </div>
                </div>                  
                
            </div>
		</div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!-- <script src="assets/js/jquery-3.2.1.min.js"></script> -->
    <script src="<?php echo base_url('js/jquery.slimscroll.js')?>"></script>
    <script src="<?php echo base_url('js/select2.min.js')?>"></script>
	<script src="<?php echo base_url('js/moment.min.js')?>"></script>
	<script src="<?php echo base_url('js/bootstrap-datetimepicker.min.js')?>"></script>
    <script src="<?php echo base_url('js/app.js')?>"></script>
	<script>
            $(function () {
                $('#datetimepicker3').datetimepicker({
                    format: 'LT'

                });
            });
            $(function () {
          var disabledDate = ['2021-03-24', '2021-03-26','2021-03-25'];
        $('.datetimepicker').datetimepicker({
            disabledDates: disabledDate
        });
    });
     </script>
     <script>
     $(document).ready(function() {
        $('#dept_id').change(function(){
            var dept_id = $('#dept_id').val();
            // console.log('hello');
            // console.log(dept_id);
                 var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        // console.log(this.responseText);
                    document.getElementById("doc_id").innerHTML = this.responseText;
                    }
                };
                
                xhttp.open("GET", "<?php echo site_url() ?>/hospital_Controller/fetchDoc?q="+dept_id, true);
                xhttp.send(); 
                
            
        });
     });
     </script>
     <script type="text/javascript">
    //<![CDATA[
    $(function() {
      $('#wrapper .version strong').text('v' + $.fn.pignoseCalendar.version);

      function onSelectHandler(date, context) {
        /**
         * @date is an array which be included dates(clicked date at first index)
         * @context is an object which stored calendar interal data.
         * @context.calendar is a root element reference.
         * @context.calendar is a calendar element reference.
         * @context.storage.activeDates is all toggled data, If you use toggle type calendar.
         * @context.storage.events is all events associated to this date
         */

        var $element = context.element;
        var $calendar = context.calendar;
        var $box = $element.siblings('.box').show();
        var text = 'You selected date ';

        if (date[0] !== null) {
          text += date[0].format('YYYY-MM-DD');
        }

        if (date[0] !== null && date[1] !== null) {
          text += ' ~ ';
        } else if (date[0] === null && date[1] == null) {
          text += 'nothing';
        }

        if (date[1] !== null) {
          text += date[1].format('YYYY-MM-DD');
        }

        $box.text(text);
      }

      function onApplyHandler(date, context) {
        /**
         * @date is an array which be included dates(clicked date at first index)
         * @context is an object which stored calendar interal data.
         * @context.calendar is a root element reference.
         * @context.calendar is a calendar element reference.
         * @context.storage.activeDates is all toggled data, If you use toggle type calendar.
         * @context.storage.events is all events associated to this date
         */

        var $element = context.element;
        var $calendar = context.calendar;
        var $box = $element.siblings('.box').show();
        var text = 'You applied date ';

        if (date[0] !== null) {
          text += date[0].format('YYYY-MM-DD');
        }

        if (date[0] !== null && date[1] !== null) {
          text += ' ~ ';
        } else if (date[0] === null && date[1] == null) {
          text += 'nothing';
        }

        if (date[1] !== null) {
          text += date[1].format('YYYY-MM-DD');
        }

        $box.text(text);
      }

      // Default Calendar
      $('.calendar').pignoseCalendar({
          select: onSelectHandler
      });

      // Input Calendar
    // $weekdays = [0 =>'Sun',1 =>'Mon',2 =>'Tue',3 =>'Wed',4 =>'Thur',5 =>'Fri',6 =>'Sat'];
      
    //    foreach($doctors as $x): 
    //    $onDays = explode(',',$x['weekdays']);
    //    $disabDays = array();
    //    foreach($weekdays as $a => $b){
    //      if(!in_array($b,$onDays)){
    //        array_push($disabDays,$a);
    //      }
    //    }
      $('.input-calendar').pignoseCalendar({
        // minDate: moment('<?php// echo mdate($datestring, $curtime) ?>'),
        apply: onApplyHandler,
        // disabledWeekdays: <?php// echo '[' . implode(', ', $disabDays) . ']' ?>,
        // buttons: true, // It means you can give bottom button controller to the modal which be opened when you click.
      });
      <?php //endforeach; ?>
      // Calendar modal
      var $btn = $('.btn-calendar').pignoseCalendar({
        apply: onApplyHandler,
        modal: true, // It means modal will be showed when you click the target button.
        buttons: true
      });

      // Color theme type Calendar
      $('.calendar-dark').pignoseCalendar({
        theme: 'dark', // light, dark, blue
        select: onSelectHandler
      });

      // Blue theme type Calendar
      $('.calendar-blue').pignoseCalendar({
        theme: 'blue', // light, dark, blue
        select: onSelectHandler
      });

      // Schedule Calendar
      $('.calendar-schedules').pignoseCalendar({
        scheduleOptions: {
          colors: {
            holiday: '#2fabb7',
            seminar: '#5c6270',
            meetup: '#ef8080'
          }
        },
        schedules: [{
          name: 'holiday',
          date: '2017-08-08'
        }, {
          name: 'holiday',
          date: '2017-09-16'
        }, {
          name: 'holiday',
          date: '2017-10-01',
        }, {
          name: 'holiday',
          date: '2017-10-05'
        }, {
          name: 'holiday',
          date: '2017-10-18',
        }, {
          name: 'seminar',
          date: '2017-11-14'
        }, {
          name: 'seminar',
          date: '2017-12-01',
        }, {
          name: 'meetup',
          date: '2018-01-16'
        }, {
          name: 'meetup',
          date: '2018-02-01',
        }, {
          name: 'meetup',
          date: '2018-02-18'
        }, {
          name: 'meetup',
          date: '2018-03-04',
        }, {
          name: 'meetup',
          date: '2018-04-01'
        }, {
          name: 'meetup',
          date: '2018-04-19',
        }],
        select: function(date, context) {
          var message = `You selected ${(date[0] === null ? 'null' : date[0].format('YYYY-MM-DD'))}.
							   <br />
							   <br />
							   <strong>Events for this date</strong>
							   <br />
							   <br />
							   <div class="schedules-date"></div>`;
          var $target = context.calendar.parent().next().show().html(message);

          for (var idx in context.storage.schedules) {
            var schedule = context.storage.schedules[idx];
            if (typeof schedule !== 'object') {
              continue;
            }
            $target.find('.schedules-date').append('<span class="ui label default">' + schedule.name + '</span>');
          }
        }
      });

      // Multiple picker type Calendar
      $('.multi-select-calendar').pignoseCalendar({
        multiple: true,
        select: onSelectHandler
      });

      // Toggle type Calendar
      $('.toggle-calendar').pignoseCalendar({
        toggle: true,
        select: function(date, context) {
          var message = `You selected ${(date[0] === null ? 'null' : date[0].format('YYYY-MM-DD'))}.
                                <br />
                                <br />
                                <strong>Events for this date</strong>
                                <br />
                                <br />
                                <div class="active-dates"></div>`;
          var $target = context.calendar.parent().next().show().html(message);

          for (var idx in context.storage.activeDates) {
            var date = context.storage.activeDates[idx];
            if (typeof date !== '<span class="ui label"><i class="fas fa-code"></i>string</span>') {
              continue;
            }
            $target.find('.active-dates').append('<span class="ui label default">' + date + '</span>');
          }
        }
      });

      // Disabled date settings.
      (function() {
        // IIFE Closure
        var times = 30;
        var disabledDates = [];
        for (var i = 0; i < times; /* Do not increase index */ ) {
          var year = moment().year();
          var month = 0;
          var day = parseInt(Math.random() * 364 + 1);
          var date = moment().year(year).month(month).date(day).format('YYYY-MM-DD');
          if ($.inArray(date, disabledDates) === -1) {
            disabledDates.push(date);
            i++;
          }
        }

        disabledDates.sort();

        var $dates = $('.disabled-dates-calendar').siblings('.guide').find('.guide-dates');
        for (var idx in disabledDates) {
          $dates.append('<span>' + disabledDates[idx] + '</span>');
        }

        $('.disabled-dates-calendar').pignoseCalendar({
          select: onSelectHandler,
          disabledDates: disabledDates
        });
      }());

      // Disabled Weekdays Calendar.
      $('.disabled-weekdays-calendar').pignoseCalendar({
        select: onSelectHandler,
        disabledWeekdays: [0, 6]
      });

      // Disabled Range Calendar.
      var minDate = moment().set('dates', Math.min(moment().day(), 2 + 1)).format('YYYY-MM-DD');
      var maxDate = moment().set('dates', Math.max(moment().day(), 24 + 1)).format('YYYY-MM-DD');
      $('.disabled-range-calendar').pignoseCalendar({
        select: onSelectHandler,
        minDate: minDate,
        maxDate: maxDate
      });

      // Multiple Week Select
      $('.pick-weeks-calendar').pignoseCalendar({
        pickWeeks: true,
        multiple: true,
        select: onSelectHandler
      });

      // Disabled Ranges Calendar.
      $('.disabled-ranges-calendar').pignoseCalendar({
        select: onSelectHandler,
        disabledRanges: [
          ['2016-10-05', '2016-10-21'],
          ['2016-11-01', '2016-11-07'],
          ['2016-11-19', '2016-11-21'],
          ['2016-12-05', '2016-12-08'],
          ['2016-12-17', '2016-12-18'],
          ['2016-12-29', '2016-12-30'],
          ['2017-01-10', '2017-01-20'],
          ['2017-02-10', '2017-04-11'],
          ['2017-07-04', '2017-07-09'],
          ['2017-12-01', '2017-12-25'],
          ['2018-02-10', '2018-02-26'],
          ['2018-05-10', '2018-09-17'],
        ]
      });

      // I18N Calendar
      $('.language-calendar').each(function() {
        var $this = $(this);
        var lang = $this.data('lang');
        $this.pignoseCalendar({
          lang: lang
        });
      });

      // This use for DEMO page tab component.
      $('.menu .item').tab();
    });
    //]]>
  </script>
  <script type="text/javascript" src="<?php echo base_url('css/cssUser/') ?>dist/js/pignose.calendar.full.min.js"></script>
</body>
</html>