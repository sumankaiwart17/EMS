<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Doctors</title>
</head>
<body>
    <!-- Navbar -->
    <?php include ('navbar.php'); ?>
        <!-- doctors -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-4 col-3">
                        <h4 class="page-title">Doctors</h4>
                    </div>
                    <div class="col-sm-8 col-9 text-right m-b-20">
                        <a href="<?php echo site_url('hospital_Controller/addDoc') ?>" class="btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Add Doctor</a>
                    </div>
                </div>
				<div class="row doctor-grid">
                <?php $modal = 0; ?>
                    <?php foreach($assocDoc as $x): ?>
                    <?php $modal = $modal + 1; ?>
                    <div class="col-md-4 col-sm-4  col-lg-3">
                        <div class="profile-widget">
                            <div class="doctor-img">
                                <a class="avatar"  data-toggle="modal" data-target="#exampleModalCenter<?php echo $modal?>"  href=""><img alt="" src="<?php echo $x['picture'] ?>"></a>
                            </div>
                            <div class="dropdown profile-action">
                                <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="<?php echo site_url('hospital_Controller/editDoc/'.$x['doc_id']) ?>"><i class="fas fa-pencil-alt m-r-5"></i> Edit</a>
                                    <a class="dropdown-item" href="<?php echo site_url('hospital_Controller/delDoc/'.$x['doc_id']) ?>" onclick="return confirm('Are you sure, you want to delete it?')"><i class="fas fa-trash m-r-5"></i> Delete</a>
                                </div>
                            </div>
                            <h4 class="doctor-name text-ellipsis"><a data-toggle="modal" data-target="#exampleModalCenter<?php echo $modal?>" href="profile.html"><?php echo $x['doc_name'] ?></a></h4>
                            <div class="doc-prof"><?php echo $x['dept_name'] ?></div>
                            <div class="user-country">
                                <i class="fas fa-map-marker"></i>&nbsp; <?php echo $x['city'].', '.$x['state'] ?>
                            </div>
                            <div class="mt-2">
                                <?php if($x['star_rating'] != 0): ?>
                            <?php echo round($x['star_rating'],1).'/5' ?><br>
                                <?php for($i=0;$i < $x['star_rating'];$i++): ?>
                                <i class="fas fa-star text-warning"></i>
                                <?php endfor; ?>
                                <?php else:  echo 'No Reviews';?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div> 
                    <div class="modal fade" id="exampleModalCenter<?php echo $modal?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                                
                                <div class="modal-body">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                    <div class="conatainer-fluid">
                                        <div class="row">
                                            <div class="col-12 col-sm-4">
                                                <img src="<?php echo $x['picture'] ?>" class="img-thumbnail rounded-square" alt="">
                                            </div>
                                            <div class="col-12 col-sm-8">
                                                <h3><?php echo $x['doc_name'] ?></h3>
                                                <p><?php echo $x['specialization'] ?></p>
                                                <div class="mt-2">
                                                <strong><?php echo round($x['star_rating'],1).' out of 5' ?></strong><br>
                                                    <?php for($i=0;$i < round($x['star_rating']);$i++): ?>
                                                    <i class="fas fa-star text-warning"></i>
                                                <?php endfor; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" >
                                            <div class="row-header mt-5 ml-3">
                                                <h4 class="text-info" style="border-bottom: 4px solid #17a2b8!important">Dr. <?php echo $x['doc_name']."'s" ?> Information</h4>
                                            </div>
                                            <div class="col-12 col-sm-6 mt-2">
                                                <p class="text-info"><strong style="border-bottom: 2px solid #17a2b8!important"> Address:</strong></p>
                                                <p><?php echo $x['city'].', '.$x['state'].', '.$x['country'].',' ?></p>
                                                <p>Pincode: <?php echo $x['zip'] ?></p>
                                            </div>
                                            <div class="col-12 col-sm-6 mt-2">
                                                <p class="text-info" ><strong style="border-bottom: 2px solid #17a2b8!important"> Contact:</strong></p>
                                                <p>Phone: <?php echo $x['phone'] ?></p>
                                                <p>Email: <?php echo $x['email_id'] ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12 col-sm-12">
                                                <h4 class="text-info" style="border-bottom: 2px solid #17a2b8!important">Experience</h4>
                                                <p><?php echo $x['experience'] ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                </div>
            </div>
        </div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</html>