
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Add Treatment</title>
</head>
<body>
    <!-- Navbar -->
<?php include ('navbar.php'); ?>
        <!-- Add Treatment -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Add Treatment</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form action="<?php echo site_url('hospital_Controller/addTreat') ?>" method="post">
							<div class="form-group">
								<label>Department Name:</label>
                                <select id="deptName" name="deptName" style="width: 300px; height: 30px; padding: 5px;" class="ml-5">
                                    <option value="" selected>Select Department</option>
                                    <?php foreach($depts as $x): ?>
                                        <option value="<?php echo $x['dept_id'] ?>"><?php echo $x['dept_name'] ?></option>
                                    <?php endforeach; ?>
                                </select><br>
                                <span class="text-info">*NOTE: If the department is not listed please add the department first</span>
                            </div>
                            <div class="form-group">
                            <label>Treatment Name:</label>
                                <select id="treatName" name="treatName" style="width: 300px; height: 30px; padding: 5px;" class="ml-5">
                                    <option value="" selected>Select a Department First</option>
                                    
                                </select>
                                <div data-parent="other" style="display: none; margin-top: 20px;">
                                    <label>Specify the Treatment name:</label>
                                    <input type="text" name="newTreatName" id="newTreatName" class="form-control">
                                    <br>
                                    <label>Treatment Description:</label>
                                    <input type="text" name="description" id="description" class="form-control">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-6 col-sm-6">
                                    <label>Duration <small class="text-muted">(In Days)</small></label>
                                    <input type="text" name="duration" id="duration" class="form-control" value="">
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label>Budget <small class="text-muted">(In INR)</small></label>
                                    <input type="text" name="budget" id="budget" class="form-control" value="">
                                </div>
                                
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Add Treatment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
			
        </div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#deptName').change(function(){
            var dept_id = $('#deptName').val();
           
            //console.log("/hospital_Controller/fetchtreat?q="+dept_id);
                 var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        //console.log(this.responseText);
                    document.getElementById("treatName").innerHTML = this.responseText;
                    }
                };
                
                xhttp.open("GET", "<?php echo site_url() ?>/hospital_Controller/fetchtreat?q="+dept_id, true);
                xhttp.send(); 
                
            
        });
    });
    $(function() {
        $("#treatName").on("change", function() {
            if($(this).val() === "other") {
                $("div[data-parent='" + $(this).val() + "']").show().siblings("[data-parent]").hide();
                
            } else {
                $("[data-parent]").hide();
            }
        });
    });
</script>

</html>