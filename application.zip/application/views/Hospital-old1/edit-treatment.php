
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Add Treatment</title>
</head>
<body>
    <!-- Navbar -->
<?php include ('navbar.php'); ?>
        <!-- Edit Treatment -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Edit Treatment</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form action="<?php echo site_url('hospital_Controller/edittreat') ?>" method="post">
							<div class="form-group row">
                                <div class="col-6 col-sm-6">
                                    <label>Treatment Name</label>
                                    <input class="form-control" type="text" name="treat_name" readonly value="<?php echo $treatData['treat_name'] ?>">
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label>Treatment ID</label>
                                    <input class="form-control" type="text" name="treat_id" readonly value="<?php echo $treatData['treat_id'] ?>">
                                </div>
							</div> 
                            <div class="form-group">
								<label>Department</label>
								<input class="form-control" type="text" name="dept" readonly value="<?php echo $treatData['dept_name'] ?>">
							</div>
                            <div class="form-group row">
                                <div class="col-6">
                                    <label>Duration <small class="text-muted">(In Days)</small>:</label>
                                    <input type="text" name="duration" id="duration" class="form-control" value="<?php echo $treatData['duration'] ?>">
                                </div>
                                <div class="col-6">
                                    <label>Budget <small class="text-muted">(In INR)</small>:</label>
                                    <input type="text" name="budget" id="budget" class="form-control" value="<?php echo $treatData['budget'] ?>">
                                </div>
                            </div>
                            
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Save Treatment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script>
    $(function() {
    $("select").on("change", function() {
        if($(this).val() === "other") {
            $("div[data-parent='" + $(this).val() + "']").show().siblings("[data-parent]").hide();
            
        } else {
            $("[data-parent]").hide();
        }
    });
});

$(document).ready(function () {
    $('#spocCheck').click(function () {
        if (this.checked) 
        //  ^
           $('#spocDet').show();
        else 
            $('#spocDet').hide();
    });
});
</script>
</body>
</html>