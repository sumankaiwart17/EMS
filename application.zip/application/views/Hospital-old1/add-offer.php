
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/bootstrap-datetimepicker.min.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Add Offer</title>
    <style>
          .cal-icon:after {
	background: transparent url("<?php echo base_url('images/') ?>calander.png") no-repeat scroll 0 0;
	bottom: 0;
	content: "";
	display: block;
	height: 19px;
	margin: auto;
	position: absolute;
	right: 15px;
	top: 0;
	width: 17px;
}
.cal-icon {
	position: relative;
	width: 100%;
}
    </style>
</head>
<body>
    <!-- Navbar -->
<?php include ('navbar.php'); ?>
        <!-- Add Patient -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2 pt-5">
                        <h4 class="page-title">Add Offer</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2 pt-3">
                        <form method="post" action="<?php echo site_url('hospital_Controller/addOffer') ?>"> 
                            <div class="row">
                                <div class="col-sm-6 pt-2">
									<div class="form-group">
										<label>Doctor: <span class="text-danger">*</span></label>
										<select name="doc_id" required class="form-control">
                                            <option value="">Select a Doctor</option>
                                        <?php foreach($docs as $x): ?>
											<option value="<?php echo $x['doc_id'] ?>"><?php echo 'Dr. '.$x['doc_name'] ?></option>
                                        <?php endforeach; ?>
										</select>
									</div>
								</div>
                                <div class="col-sm-6 pt-2">
                                    <div class="form-group">
                                        <label>Coupon Code: <span class="text-danger">*</span></label>
                                        <input class="form-control" required name="coupon_code" style="text-transform: uppercase;" id="coupon_code" type="text">
                                    </div>
                                </div>
                                <div class="col-sm-6 pt-2">
                                    <div class="form-group">
                                        <label>Coupon Title: <span class="text-danger">*</span></label>
                                        <input class="form-control" required name="coupon_title"  id="coupon_title" type="text">
                                    </div>
                                </div>
                                <div class="col-sm-6 pt-2">
                                    <div class="form-group">
                                        <label>Description: <span class="text-danger">*</span></label>
                                        <textarea name="coupon_desc" class="form-control" id="" rows="2"></textarea>
                                    </div>
                                </div>
								<div class="col-sm-6 pt-2">
                                    <div class="form-group">
                                        <label>Valid Till: <span class="text-danger">*</span></label>
                                        <div class="cal-icon">
                                            <input type="text" required class="form-control datetimepicker" name="valid_till" id="valid_till">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 pt-2">
									<div class="form-group gender-select">
										<label class="gen-label">Status: <span class="text-danger">*</span></label>
										<div class="form-check-inline">
											<label class="form-check-label">
												<input type="radio" required name="status" value="1" checked class="form-check-input">Active
											</label>
										</div>
										<div class="form-check-inline">
											<label class="form-check-label">
												<input type="radio" required name="status" value="0" class="form-check-input">Inactive
											</label>
										</div>
									</div>
                                </div>
                                <div class="col-sm-6 pt-2">
                                    <div class="form-group">
                                        <label>Discount: <span class="text-danger">*</span></label>
                                        <input class="form-control" required type="number" min="1" max="100" name="discount" id="discount">
                                    </div>
                                </div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button type="submit" class="btn btn-primary submit-btn">Add Coupon</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
			
        </div>

        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="<?php echo base_url('js/jquery.slimscroll.js')?>"></script>
    <script src="<?php echo base_url('js/select2.min.js')?>"></script>
	<script src="<?php echo base_url('js/moment.min.js')?>"></script>
	<script src="<?php echo base_url('js/bootstrap-datetimepicker.min.js')?>"></script>
    <script src="<?php echo base_url('js/app.js')?>"></script>
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#prevpic').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#propic").change(function(){
    readURL(this);
});
</script>
</body>
</html>