
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Add Department</title>
</head>
<body>
    <!-- Navbar -->
<?php include ('navbar.php'); ?>
        <!-- Add Department -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Add Department</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form action="<?php echo site_url('hospital_Controller/addDept') ?>" method="post">
							<div class="form-group">
								<label>Department Name:</label>
                                <select id="deptName" name="deptName" style="width: 300px; height: 30px; padding: 5px;" class="ml-5">
                                    <?php foreach($depts as $x): ?>
                                        <option value="<?php echo $x['dept_id'] ?>"><?php echo $x['dept_name'] ?></option>
                                    <?php endforeach; ?>
                                    <option value="other">Other</option>
                                </select>
                                <div data-parent="other" style="display: none; margin-top: 20px;">
                                    <label>Specify the name:</label>
                                    <input type="text" name="newDeptName" id="newDeptName" class="form-control">
                                    <br>
                                    <label>Description:</label>
                                    <input type="text" name="description" id="description" class="form-control">
                                </div>
							</div>
                            <div class="form-group row">
                                <div class="col-6">
                                    <label>Opening Time:</label>
                                    <input type="time" name="openAt" id="openAt" class="form-control">
                                </div>
                                <div class="col-6">
                                    <label>Closing Time:</label>
                                    <input type="time" name="closeAt" id="closeAt" class="form-control">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-6">
                                    <label>Block No:</label>
                                    <input type="text" name="block" id="block" class="form-control">
                                </div>
                                <div class="col-6">
                                    <label>Floor No:</label>
                                    <input type="text" name="floor" id="floor" class="form-control">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-6">
                                    <label>Total No. of beds:</label>
                                    <input type="number" name="total_beds" min="1" id="total_beds" class="form-control">
                                </div>
                                <div class="col-6">
                                    <label>Available No. of beds:</label>
                                    <input type="number" name="available_beds" min="1" id="available_beds" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Facilities:</label>
                                <textarea cols="30" rows="2" name="facilities" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Services:</label>
                                <textarea cols="30" rows="2" name="services" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label>AddOn Services:</label>
                                <textarea cols="30" rows="2" name="addOns" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" id="spocCheck" name="spocCheck">
                                <label>SPOC Available?</label>
                                <div id="spocDet" style="display: none; margin-top: 20px;">
                                    <label>SPOC Name:</label>
                                    <input type="text" name="spoc" id="spoc" class="form-control">
                                    <br>
                                    <label>SPOC Contact No:</label>
                                    <input type="text" name="spocNo" id="spocNo" class="form-control">
                                    <br>
                                    <label>SPOC Email ID:</label>
                                    <input type="email" name="spocEmail" id="spocEmail" class="form-control">    
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="display-block">Department Status:</label>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_active" value="1" checked>
									<label class="form-check-label" for="product_active">
									Active
									</label>
								</div>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_inactive" value="0">
									<label class="form-check-label" for="product_inactive">
									Inactive
									</label>
								</div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Add Department</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
			
        </div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script>
    $(function() {
    $("select").on("change", function() {
        if($(this).val() === "other") {
            $("div[data-parent='" + $(this).val() + "']").show().siblings("[data-parent]").hide();
            
        } else {
            $("[data-parent]").hide();
        }
    });
});
$(document).ready(function () {
    $('#spocCheck').click(function () {
        if (this.checked) 
        //  ^
           $('#spocDet').show();
        else 
            $('#spocDet').hide();
    });
});
</script>
</body>
</html>