
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/bootstrap-datetimepicker.min.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Edit Patient</title>
    <style>
          .cal-icon:after {
	background: transparent url("<?php echo base_url('images/') ?>calander.png") no-repeat scroll 0 0;
	bottom: 0;
	content: "";
	display: block;
	height: 19px;
	margin: auto;
	position: absolute;
	right: 15px;
	top: 0;
	width: 17px;
}
.cal-icon {
	position: relative;
	width: 100%;
}
    </style>
</head>
<body>
    <!-- Navbar -->
<?php include ('navbar.php'); ?>
        <!-- Add Patient -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Edit Patient</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form method="post" action="<?php echo site_url('hospital_Controller/editPatient') ?>"> 
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Patient ID: </label>
                                        <input class="form-control" readonly name="p_id" value="<?php echo $pData[0]['p_id'] ?>" type="text">
                                        
                                    </div>
                                </div>
                                <div class="col-sm-6">
									<div class="form-group">
										<label>Doctor: <span class="text-danger">*</span></label>
										<select name="doc_id" required class="form-control">
                                            <option value="">Select a Doctor</option>
                                        <?php foreach($docs as $x): ?>
                                            
											<option <?php if($x['doc_id'] == $pData[0]['doc_id']){ echo 'selected';} ?> value="<?php echo $x['doc_id'] ?>"><?php echo 'Dr. '.$x['doc_name'] ?></option>
                                        <?php endforeach; ?>
										</select>
									</div>
								</div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Full Name: <span class="text-danger">*</span></label>
                                        <input class="form-control" required name="p_name" id="p_name" value="<?php echo $pData[0]['p_name'] ?>" type="text">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Email ID: <span class="text-danger">*</span></label>
                                        <input class="form-control" required type="email" name="email_id" value="<?php echo $pData[0]['email_id'] ?>" id="email_id">
                                    </div>
                                </div>
								<div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Date of Birth: <span class="text-danger">*</span></label>
                                        <div class="cal-icon">
                                            <input type="text" required value="<?php echo $pData[0]['dob'] ?>" class="form-control datetimepicker" name="dob" id="dob">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
									<div class="form-group gender-select">
										<label class="gen-label">Gender: <span class="text-danger">*</span></label>
										<div class="form-check-inline">
											<label class="form-check-label">
												<input type="radio" required name="gender" <?php if($pData[0]['gender'] == 'male'){ echo 'checked';} ?> value="male" class="form-check-input">Male
											</label>
										</div>
										<div class="form-check-inline">
											<label class="form-check-label">
												<input type="radio" required name="gender" <?php if($pData[0]['gender'] == 'female'){ echo 'checked';} ?> value="female" class="form-check-input">Female
											</label>
										</div>
									</div>
                                </div>
								<div class="col-sm-12">
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<label>Address <span class="text-danger">*</span></label>
												<input type="text" required value="<?php echo $pData[0]['address'] ?>" class="form-control" name="address" id="address">
											</div>
										</div>
									</div>
								</div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Phone No.: <span class="text-danger">*</span></label>
                                        <input class="form-control" required type="text" value="<?php echo $pData[0]['phone'] ?>" name="phone" id="phone">
                                    </div>
                                </div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button type="submit" class="btn btn-primary submit-btn">Save Patient</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
			
        </div>

        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="<?php echo base_url('js/jquery.slimscroll.js')?>"></script>
    <script src="<?php echo base_url('js/select2.min.js')?>"></script>
	<script src="<?php echo base_url('js/moment.min.js')?>"></script>
	<script src="<?php echo base_url('js/bootstrap-datetimepicker.min.js')?>"></script>
    <script src="<?php echo base_url('js/app.js')?>"></script>
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#prevpic').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#propic").change(function(){
    readURL(this);
});
</script>
</body>
</html>