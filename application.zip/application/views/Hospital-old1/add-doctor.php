
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssHos/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
    <title>Dashboard</title>
</head>
<body>
    <!-- Navbar -->
<?php include ('navbar.php'); ?>
        <!-- Add Doctor -->
        
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Add Doctor</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form action="<?php echo site_url('hospital_Controller/addDoc') ?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>License No.</label>
                                        <input class="form-control" name="docId" type="text" value="<?php echo set_value('docId') ?>">
                                        <span class="text-danger"><?php echo form_error('docId') ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Full Name</label>
                                        <input class="form-control" name="docName" type="text" value="<?php echo set_value('docName') ?>">
                                        <span class="text-danger"><?php echo form_error('docName') ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input class="form-control" name="emailId" type="email" value="<?php echo set_value('emailId') ?>">
                                        <span class="text-danger"><?php echo form_error('emailId') ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input class="form-control" name="pass" type="password" value="<?php echo set_value('pass') ?>">
                                        <span class="text-danger"><?php echo form_error('pass') ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Confirm Password</label>
                                        <input class="form-control" name="cpass" type="password" value="<?php echo set_value('cpass') ?>">
                                        <span class="text-danger"><?php echo form_error('cpass') ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
									<div class="form-group">
										<label>Adhar No.</label>
										<input type="text" name="adhar" class="form-control " value="<?php echo set_value('adhar') ?>">
                                        <span class="text-danger"><?php echo form_error('adhar') ?></span>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label>Specialization</label>
										<input type="text" name="specialization" class="form-control " value="<?php echo set_value('specialization') ?>">
                                        <span class="text-danger"><?php echo form_error('specialization') ?></span>
									</div>
								</div>
                                <div class="col-sm-6">
									<div class="form-group">
										<label>Avatar</label>
										<div class="profile-upload">
											<div class="upload-img">
												<img alt="" id="prevpic" src="<?php echo base_url('images/user.jpg') ?>">
											</div>
											<div class="upload-input">
												<input type="file" class="form-control" id="propic" name="picture">
                                                <span class="text-danger"><?php?></span>
											</div>
										</div>
									</div>
                                </div>
                                <div class="col-sm-12">
									<div class="row">
										<div class="col-sm-6 col-md-6 col-lg-3">
											<div class="form-group">
												<label>Country</label>
												<input type="text" name="country" class="form-control " value="<?php echo set_value('country') ?>">
                                                <span class="text-danger"><?php echo form_error('country') ?></span>
											</div>
										</div>
										<div class="col-sm-6 col-md-6 col-lg-3">
											<div class="form-group">
												<label>City</label>
												<input type="text" name="city" class="form-control" value="<?php echo set_value('city') ?>">
                                                <span class="text-danger"><?php echo form_error('city') ?></span>
											</div>
										</div>
										<div class="col-sm-6 col-md-6 col-lg-3">
											<div class="form-group">
												<label>State/Province</label>
												<input type="text" name="state" class="form-control " value="<?php echo set_value('state') ?>">
                                                <span class="text-danger"><?php echo form_error('state') ?></span>
											</div>
										</div>
										<div class="col-sm-6 col-md-6 col-lg-3">
											<div class="form-group">
												<label>Postal Code</label>
												<input type="text" name="zip" class="form-control" value="<?php echo set_value('zip') ?>">
                                                <span class="text-danger"><?php echo form_error('zip') ?></span>
											</div>
										</div>
									</div>
								</div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Phone </label>
                                        <input class="form-control" name="phone" type="text" value="<?php echo set_value('phone') ?>">
                                        <span class="text-danger"><?php echo form_error('phone') ?></span>
                                    </div>
                                </div>
                            </div>
							<div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Add Doctor</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#prevpic').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#propic").change(function(){
    readURL(this);
});
</script>
</body>
</html>