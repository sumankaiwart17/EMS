<?php if (isset($_SESSION['userLog']) && $_SESSION['userLog'] == true) {
  $userData = $this->db->where('email_id', $_SESSION['email_id'])
    ->get('user_details')
    ->result_array();
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
        integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w=="
        crossorigin="anonymous" />
    <link rel="stylesheet" href="<?php echo base_url('css/cssUser/style.css') ?>">
    <title></title>
    <style>
    .login-btn {
        padding: 5px 8px 5px 8px;
        border: 2px solid whitesmoke;
        color: white;
        transition: 0.25s ease-in-out;
    }

    .login-btn:hover {
        transform: scale(1.2);
        background: whitesmoke;
        cursor: pointer;
        color: red;
    }

    .dropdown-item:focus,
    .dropdown-item:hover {
        color: #16181b;
        text-decoration: blue;
        background-color: #007BD2;
    }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-flor">
        <div class="container">
            <a class="navbar-brand" href="#"><img src="<?php echo base_url('images/AAHRS_logo5.png') ?>" alt="logo"
                    style="height: 43px; margin-top: 5px;"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto"><?php if (!isset($userData)) : ?>
                    <li class="nav-item">
                        <a class="nav-link  " href="<?php echo site_url('user/login-page') ?>"><span
                                class="login-btn btn btn-danger">Join Now</span> </a>
                    </li>
                    <?php else : ?>
                    <li class="nav-item noti">
                        <a class="nav-link mt-2 mr-2" href="#"><i class="fas fa-bell fa-lg"></i></a>
                    </li>
                    <li class="nav-item bell">
                        <a class="nav-link mt-2 mr-2" href="#"><i class="fas fa-comment fa-lg"></i></a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="<?php if ($userData[0]['picture'] != '') {
                                            echo $userData[0]['picture'];
                                          } else {
                                            echo base_url('images/avatar.png');
                                          } ?>" class="img rounded-circle" style="height: 40px;width:40px;"
                                alt="profilepic">
                        </a>
                        <div class="dropdown-menu" style="z-index:1;" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item"
                                href="<?php echo site_url('userProfile_Controller/myaccount?id=' . $_SESSION['email_id'] . '') ?>">My
                                Account</a>
                            <a class="dropdown-item"
                                href="<?php echo site_url('userProfile_Controller/myappoint') ?>">My Appointments</a>
                            <a class="dropdown-item"
                                href="<?php echo site_url('userProfile_Controller/feedbacks') ?>">My Feedbacks</a>
                            <a class="dropdown-item"
                                href="<?php echo site_url('userProfile_Controller/medicalHis') ?>">Medical History</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo site_url('logIO_Controller/logout') ?>">Log
                                Out</a>
                        </div>
                    </li>
                    <?php endif; ?>
                </ul>

            </div>
        </div>

    </nav>
    <div class="container mt-3 mb-3">

        <div class="row desk-nav justify-content-center">
            <div class=" col-12 col-sm-6 col-md-2 col-lg-2 text-center"><a
                    href="<?php echo site_url('user/timeline') ?>"
                    class="user-link <?php if ($this->uri->segment(2) == 'timeline') : ?> <?php echo 'active' ?> <?php endif; ?>"
                    class="user-link">Timeline</a></div>
            <div class=" col-12 col-sm-6 col-md-2 col-lg-2 text-center"><a
                    href="<?php echo site_url('user/reviews') ?>"
                    class="user-link <?php if ($this->uri->segment(2) == 'reviews') : ?> <?php echo 'active' ?> <?php endif; ?>">Reviews</a>
            </div>
            <div class=" col-12 col-sm-6 col-md-2 col-lg-2 text-center"><a
                    href="<?php echo site_url('user/top-hospitals') ?>"
                    class="user-link <?php if ($this->uri->segment(2) == 'top_hospitals') : ?> <?php echo 'active' ?> <?php endif; ?>">Top
                    Hospitals</a></div>
            <div class=" col-12 col-sm-6 col-md-2 col-lg-2 text-center"><a
                    href="<?php echo site_url('user/top-doctors') ?>"
                    class="user-link <?php if ($this->uri->segment(2) == 'top_doctors') : ?> <?php echo 'active' ?> <?php endif; ?>"
                    class="user-link">Top Doctors</a></div>
        </div>
        <div class="row mob-nav justify-content-center">
            <div class=" col-3 col-sm-3 text-center"><a href="<?php echo site_url('user/timeline') ?>"
                    class="user-link <?php if ($this->uri->segment(2) == 'timeline') : ?> <?php echo 'active' ?> <?php endif; ?>"
                    class="user-link"><i class="fas fa-stream"></i></a></div>
            <div class=" col-3 col-sm-3 col-md-2 col-lg-2 text-center"><a
                    href="<?php echo site_url('user/reviews') ?>"
                    class="user-link <?php if ($this->uri->segment(2) == 'reviews') : ?> <?php echo 'active' ?> <?php endif; ?>"><i
                        class="fas fa-star-half-alt"></i></a>
            </div>
            <div class=" col-3 col-sm-3 col-md-2 col-lg-2 text-center"><a
                    href="<?php echo site_url('user/top-hospitals') ?>"
                    class="user-link <?php if ($this->uri->segment(2) == 'top_hospitals') : ?> <?php echo 'active' ?> <?php endif; ?>"><i
                        class="fas fa-hospital"></i></a>
            </div>
            <div class=" col-3 col-sm-3 col-md-2 col-lg-2 text-center"><a
                    href="<?php echo site_url('user/top-doctors') ?>"
                    class="user-link <?php if ($this->uri->segment(2) == 'top_doctors') : ?> <?php echo 'active' ?> <?php endif; ?>"
                    class="user-link"><i class="fas fa-user-md"></i></a></div>
        </div>

    </div>


    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
</body>

</html>