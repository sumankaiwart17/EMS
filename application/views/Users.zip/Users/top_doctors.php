<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/cssUser/style.css') ?>">
    <title>AAHRS | Top Doctors</title>
    <style>
    .card {
        box-shadow: 10px 10px 8px #888888;
        transition: 0.3s ease-in-out;
        cursor: pointer;
    }

    .card:hover {
        transform: scale(1.02);
    }
    </style>
</head>
<?php
$alert = '';
$book_status = '';
if (isset($_SESSION['book_status']))
    $book_status = $_SESSION['book_status'];

if ($book_status != 0) {
    $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        Booking Successful!! Your Booking ID is ' . $book_status . '
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
                    </div>';
}
?>

<body class="bg-body">
    <?php include('navbar.php'); ?>
    <div class="container mt-2">
        <div class="row mb-5">
            <?php
            //print_r($topDocs);
            ?>
            <!-- left Bar -->
            <?php include('left-sidebar.php'); ?>
            <!-- top hospitals -->
            <div class="col-12 col-sm-12 col-md-10 col-lg-8 mb-2">
                <div class="card card-body pb-0"
                    style="width: 100%; border-radius:0px;border-left: 4px ridge red; box-shadow: 0px 0px 0px">
                    <blockquote>
                        <p><strong class="text-danger">Note:</strong> Top Doctors according to user reviews and ratings.
                        </p>
                    </blockquote>
                </div>

                <!-- <h4>Top Hospitals</h4> -->
                <div class="row docData pt-2">
                    <?php foreach ($topDocs as $x) :
                    ?>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-6"
                        style="margin-top: 15px; padding-left: 5px; padding-right: 5px">
                        <div class="card p-2 card-body">
                            <div class="row">
                                <img src="<?php echo $x['picture']
                                                ?>" class="img-thumbnail float-left rounded-square ml-3"
                                    style="height:90px;width:80px; border:none;" alt="">

                                <?php $ontimecount = number_format(($x['star_rating_ontime']*20),0)?>
                                <?php if($ontimecount >= 75):?>
                                <span class="badge badge-success position-absolute ml-4 p-1"
                                    style="border-radius:50px; margin-top:95px; font-size:8px;"><i
                                        class="fas fa-thumbs-up"></i>
                                    <?=$ontimecount?>% on time
                                </span>
                                <?php elseif($ontimecount>40 && $ontimecount<75):?>
                                <span class="badge badge-warning position-absolute ml-4 p-1"
                                    style="border-radius:50px; margin-top:95px; font-size:8px;"><i
                                        class="fas fa-thumbs-up"></i>
                                    <?=$ontimecount?>% on time
                                </span>
                                <?php elseif($ontimecount<=40):?>
                                <span class="badge badge-danger position-absolute ml-4 p-1"
                                    style="border-radius:50px; margin-top:95px; font-size:8px;"><i
                                        class="fas fa-thumbs-down"></i>
                                    <?=$ontimecount?>% on time
                                </span>
                                <?php endif; ?>

                                <div class="col-6 m-0 p-1">
                                    <h5 style="font-size:18px;"><a href="<?php echo site_url('mainController/viewDoctor/' . $x['doc_id'])
                                                                                ?>" class="text-info"><?php echo $x['doc_name']
                                                                                                        ?></a> <span
                                            class="badge p-1 badge-success position-absolute ml-1 mt-1 text-white font-weight-bold"
                                            style="border-radius: 50px; font-size: 8px;"><i
                                                class="fas fa-check-circle text-white"></i> Verified</span></h5>
                                    <p class="m-0 p-0" style="font-size:14px;"> <small style=""
                                            class="text-muted">Dental over 12 years of experience</small></p>
                                    <p class="text-muted m-0 mt-1 p-0" style="font-size:12px;">Appointment Fee:
                                        <strong><i class="fas fa-rupee-sign"></i> 499/-</strong>
                                    </p>

                                </div>
                                <div class="col-3 mt-3 pr-3 row justify-content-center">
                                    <h6 class="text-danger text-center p-0 m-0 mt-2" style="font-size:12px;">
                                        <?php echo $x['review_count'] ?>
                                        Review<?php if ($x['review_count'] > 1) {
                                                                                                                                                            echo 's';
                                                                                                                                                        } ?>
                                    </h6>
                                    <p class="p-0 m-0" style="font-size:12px;"><?php echo round($x['star_rating'], 1)
                                                                                    ?> out of 5</p>
                                    <div id="rateYo<?php echo $x['doc_id']
                                                        ?>" class="m-0 p-0"></div>

                                    <a href="" style="font-size:10px;" class="btn btn-primary member mt-3 p-1"
                                        data-toggle="modal"
                                        data-target="#modal<?php echo $x['doc_id']
                                                                                                                                                            ?>">Book
                                        Appointment</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach;
                    ?>
                </div>
            </div>
            <!-- Reviews -->
            <!-- <div class="col-sm-8 bg-light revData">
                <?php if ($book_status != '') {
                    echo $alert;
                    unset($_SESSION['book_status']);
                }
                ?>
                <?php foreach ($topDocs as $x) : ?>
                    <div class="mt-3 pb-2" style="border-bottom: 2px ridge #AFABAB;">
                        <div class="row">
                            <div class="col-12">
                                <img src="<?php echo $x['picture'] ?>" class="img-thumbnail ml-3 mr-3 float-left rounded-circle" style="height: 70px; width:70px;" alt="">

                                <i class="fas fa-ellipsis-v fa-lg mt-2 float-right"></i>
                                <h5 class="pt-2"><a href=""><?php echo $x['name'] ?></a> reviewed
                                    <?php if (isset($x['doc_name'])) : ?>
                                        <a href=""><strong class="rev-sub"><?php echo 'Dr. ' . $x['doc_name'] ?> </strong></a>
                                    <?php elseif (isset($x['hos_name']) && isset($x['dept_name'])) : ?>
                                        <a href=""><strong class="rev-sub"><?php echo $x['dept_name'] . ' dept, ' . $x['hos_name'] ?></strong></a>
                                    <?php elseif (isset($x['hos_name'])) : ?>
                                        <a href=""><strong class="rev-sub"><?php echo $x['hos_name'] ?> </strong></a>
                                    <?php endif; ?><br>
                                    <small style="font-size:13px;"><?php $date = date_create($x['datetime']);
                                                                    echo date_format($date, 'd/m/Y'); ?></small>
                                </h5>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-9">
                                <strong class="pl-2 mt-2 text-info" style="font-size: 18px;"><?php echo $x['review_title'] ?></strong>
                                <p class="pl-2 pt-2 wwdtext"><?php echo $x['review_content'] ?></p>
                            </div>
                            <div class="col-3">
                                <div class="mt-2">
                                    <h5 class="text-center"><?php echo $x['star_rating'] ?> out of 5</h5>
                                    <div class="row justify-content-center">
                                        <?php if (isset($x['doc_name'])) : ?>
                                            <div id="rateYo<?php echo $x['review_id'] . $x['doc_id'] ?>"></div>
                                        <?php elseif (isset($x['hos_name']) && isset($x['dept_name'])) : ?>
                                            <div id="rateYo<?php echo $x['review_id'] . $x['dept_id'] ?>"></div>
                                        <?php elseif (isset($x['hos_name'])) : ?>
                                            <div id="rateYo<?php echo $x['review_id'] . $x['hos_id'] ?>"></div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-4 pl-5"><i class="fas fa-thumbs-up icons"></i>&nbsp;Like</div>
                            <div class="col-4 pl-5"><i class="fas fa-comment icons"></i>&nbsp;Comments</div>
                            <div class="col-4 pl-5"><i class="fas fa-share icons"></i>&nbsp;Share</div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div> -->
            <!-- right Bar -->
            <div id="sidebar" class="col-sm-2">
                <div id="recommend" class=" mb-3">
                    <a href="<?php echo site_url('userProfile_Controller/postReview') ?>"
                        class="btn text-white btn-lg font-weight-bold btn-danger">Post a Review</a>
                </div>
                <div id="" class="pl-1 mb-3">
                    <a href="#">
                        <h5 class="sidebar-header">Sort By</h5>
                    </a>
                    <p><a href="">Popularity</a><br>
                        <a href="">Latest</a><br>
                        <a href="">Most Liked</a>
                    </p>
                </div>
                <div id="" class="pl-1 mb-3">
                    <a href="#">
                        <h5 class="sidebar-header">Filters</h5>
                    </a>
                    <div>
                        <p class="ml-2" style="color: #C55A11;">By Hospital</p>
                        <?php $c = 0;
                        foreach ($filters['hos'] as $x) :
                            $c++;
                        ?>

                        <input type="checkbox" class="filterCheck" id="hos_id" value="<?php echo $x['hos_id']
                                                                                            ?>">&nbsp;<label
                            for="<?php echo $x['hos_id']
                                                                                                                    ?>"><?php echo $x['hos_name']
                                                                                                                        ?></label><br>
                        <?php if ($c == 4) {
                                break;
                            }
                        endforeach;
                        ?>
                        <a href="" data-toggle="modal" data-target="#moreFilter" class="ml-2"
                            style="color: #C55A11;">+more</a>

                    </div>
                    <div>
                        <p class="ml-2" style="color: #C55A11;">By Department</p>

                        <?php $c = 0;
                        foreach ($filters['depts'] as $x) :
                            $c++;
                        ?>
                        <input type="checkbox" class="filterCheck" id="dept_id" value="<?php echo $x['dept_id']
                                                                                            ?>">&nbsp;<label
                            for="<?php echo $x['dept_id']
                                                                                                                    ?>"><?php echo $x['dept_name']
                                                                                                                        ?></label><br>
                        <?php if ($c == 4) {
                                break;
                            }
                        endforeach;
                        ?>
                        <a href="" data-toggle="modal" data-target="#moreFilter" class="ml-2"
                            style="color: #C55A11;">+more</a>

                    </div>
                    <div>
                        <p class="ml-2" style="color: #C55A11;">By Treatment</p>


                        <input type="checkbox" class="filterCheck" id="doc_id" value="">&nbsp;<label for="">Cosmetic
                            Surgery</label><br>
                        <input type="checkbox" class="filterCheck" id="doc_id" value="">&nbsp;<label for="">Bypass
                            Surgery</label><br>
                        <input type="checkbox" class="filterCheck" id="doc_id" value="">&nbsp;<label for="">Ear
                            Infection</label><br>
                        <input type="checkbox" class="filterCheck" id="doc_id" value="">&nbsp;<label
                            for="">Angioplast</label><br>

                        <a href="" class="ml-2" style="color: #C55A11;">+more</a>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="moreFilter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content" style="border-radius: 10px;">
                <div class="modal-header bg-flor">
                    <h4 class="modal-title text-white" id="exampleModalLongTitle">Filter</h4>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row">
                            <div class="form-group col-4">
                                <h6>Hospitals</h6>
                                <input list="hospital" class="form-control" name="hospital">
                                <datalist id="hospital">
                                    <?php foreach ($filters['hos'] as $x) :
                                    ?>
                                    <option value="<?php echo $x['hos_name']
                                                        ?>">
                                        <?php endforeach;
                                        ?>
                                </datalist>
                            </div>
                            <div class="form-group col-4">
                                <h6>Department</h6>
                                <input list="department" class="form-control" name="department">
                                <datalist id="department">
                                    <?php foreach ($filters['depts'] as $x) :
                                    ?>
                                    <option value="<?php echo $x['dept_name']
                                                        ?>">
                                        <?php endforeach;
                                        ?>
                                </datalist>
                            </div>
                            <div class="form-group col-4">
                                <h6>Treatment</h6>
                                <input list="treatment" class="form-control" name="treatment">
                                <datalist id="treatment">
                                    <option value="Cosmetic Surgery">
                                    <option value="Bypass Surgery">
                                    <option value="Ear Infection">
                                    <option value="Angioplast">
                                </datalist>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger">OK</button>
                </div>
            </div>
        </div>
    </div>
    <!-- <script>
    var myDiv = $('.wwdtext');
    myDiv.text(myDiv.text().substring(0,200));
    </script> -->
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"
        integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script>
    $(document).ready(function() {
        $(".filterCheck").click(function() {

            var action = 'data';
            var hos_id = get_filter_text('hos_id');
            var dept_id = get_filter_text('dept_id');
            // var doc_id = get_filter_text('doc_id');
            console.log(hos_id + ' ' + dept_id);
            $.ajax({
                url: '<?php echo site_url('userProfile_Controller/fetchDoc') ?>',
                method: 'POST',
                data: {
                    action: action,
                    hos_id: hos_id,
                    dept_id: dept_id,
                    // doc_id: doc_id,
                },
                success: function(response) {
                    //console.log(response);
                    $(".docData").html(response);
                }

            });
        });


        function get_filter_text(text_id) {

            var filterData = [];
            $('#' + text_id + ':checked').each(function() {
                filterData.push($(this).val());
            });

            return filterData;
        }
    });
    </script>
    <script>
    $(function() {
        <?php foreach ($topDocs as $x) : ?>
        $("#rateYo<?php echo $x['doc_id'] ?>").rateYo({
            rating: <?php echo $x['star_rating'] ?>,
            readOnly: true,
            starWidth: "15px",
            spacing: "2px"
        });
        <?php endforeach; ?>
    });
    </script>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
</body>

</html>